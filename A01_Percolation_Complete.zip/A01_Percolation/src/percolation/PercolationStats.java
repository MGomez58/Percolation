/**
 * A01 - Percolation & PercolationStats
 */
package percolation;

import edu.princeton.cs.algs4.StdStats;

/**
 *
 * @author Miguel Gomez
 *
 */
public class PercolationStats {

	Percolation sim;

	double x_t; // the fraction of open sites in computational experiment T
	int Num_com; // the number of computational experiments to run
	int dim; // the dimensions of the grid to be NxN
	double[] Mean_values_1toT;
	double mu = 0.0; // mu used to calculate the mean for the simulation
	double variance = 0.0; //

	/**
	 * Creates a new Percolation object of dimensions N*N to run T times and
	 * obtain stats for the simulation
	 *
	 * @param N
	 *            The value used to create the matrix
	 * @param T
	 *            The value for the number of times to run the simulation
	 */
	public PercolationStats(int N, int T) {
		try {
			if (N <= 0) {
				throw new IllegalArgumentException("N must be greater than 0");

			}
			if (T <= 0) {
				throw new IllegalArgumentException("T must be greater than 0");
			}

			dim = N; // dimensions of matrix
			Num_com = T; // number of times to run computation

			// array containing the values of the mean for each one of the
			// simulations to be used in calculating the Standard Deviation
			Mean_values_1toT = new double[T + 1];
			for (int i = 0; i <= T; i++) {
				sim = new Percolation(N); // New simulation of NxN
				sim.fillSites(sim); // Filling that simulation

				x_t = sim.counter; // value of the number of open sites in this
									// simulation

				// used before realizing I was to use StdStats
				// mu = mu + (x_t / (N * N)); // sum of all open sites divided
				// by
				// number of sites

				// adds the mean for this simulation
				Mean_values_1toT[i] = (x_t / (N * N));

			}

			System.out.println("Mean()           = " + this.mean());
			System.out.println("stdDev()         = " + this.stdDiv());
			System.out.println("confidenceLow()  = " + this.confidenceLow());
			System.out.println("confidenceHigh() = " + this.confidenceHigh());

		} catch (IllegalArgumentException e) {
			System.err.print(e.getMessage() + "\n\n");

		}
	}

	/**
	 * Computes the mean for the aggregate total number of simulations
	 *
	 * @return
	 */
	public double mean() {
		return StdStats.mean(Mean_values_1toT);

		// return mu/(Num_com);
	}

	/**
	 * Computes the Standard deviation for the aggregate total number of
	 * simulations
	 *
	 * @return
	 */
	public double stdDiv() {

		return StdStats.stddev(Mean_values_1toT);

		// created this below before realizing that I had to use StdStats

		// double result;
		// for (int i = 0; i < Mean_values_1toT.length; i++) {
		// double temp = (Mean_values_1toT[i] - this.mean()) *
		// (Mean_values_1toT[i] - this.mean());
		// Mean_values_1toT[i] = temp;
		// variance = variance + Mean_values_1toT[i];
		// }
		// result = Math.sqrt(variance / (Num_com - 1));
		// return result;
	}

	/**
	 * Computes the Low end point of confidence interval
	 *
	 * @return The value of the Low point
	 */
	public double confidenceLow() {
		double result = this.mean() - (1.96 * (stdDiv())) / Math.sqrt(Num_com);

		return result;
	}

	/**
	 * Computes the High end point of confidence interval
	 *
	 * @return The value of the High point
	 */
	public double confidenceHigh() {
		double result = this.mean() + (1.96 * (stdDiv())) / Math.sqrt(Num_com);

		return result;
	}

	/**
	 * Testing the Stats and printing out the Stats for the specified parameters
	 *
	 * @param args
	 *            The class to be tested set to run and provide the Stats
	 */
	public static void main(String[] args) {

		PercolationStats test;
		System.out.println("PercolationStats(0, 100) : \nThis is to show the exception thrown" + " when n <= 0\n");
		test = new PercolationStats(0, 100);

		System.out.println("PercolationStats(100, 0) : \nThis is to show the exception thrown" + " when T <= 0\n");
		test = new PercolationStats(100, 0);

		System.out.println("\nPercolationStats(200, 100)");
		test = new PercolationStats(200, 100);

		System.out.println("\nPercolationStats(200, 100)");
		test = new PercolationStats(200, 100);

		System.out.println("\nPercolationStats(2, 100000)");
		test = new PercolationStats(2, 100000);

	}

}
