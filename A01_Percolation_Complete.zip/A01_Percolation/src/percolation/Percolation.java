/**
 * A-01 Percolation assignment
 */
package percolation;


import edu.princeton.cs.algs4.StdRandom;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

/**
 *
 * @author Miguel Gomez
 *
 */
public class Percolation {

	// updated the file to use WeightedQuickUnionUF instead since it is
	// specification within the assignment PDF
	WeightedQuickUnionUF uf1;

	// int matrix to be used for the simulation
	int[][] sites;

	// changed dim to be a public int instead of static
	int dim;

	// values to be used for the virtual top and bottom of the
	// WeightedQuickUnionUF
	int top, bottom;

	// counter for the number of opened sites and errors
	int counter = 0;
	int errs = 0;

	/**
	 * creates an N�by�N grid, with all sites blocked
	 *
	 * @param n
	 *             The value to be used for dimensions of matrix
	 *
	 */
	public Percolation(int n) {
		try{
			if(n <= 0)
			{
				throw new IllegalArgumentException("N must be greater than 0");
			}

		sites = new int[n][n];
		dim = n;
		top = 0;
		bottom = ((n + 2) * (n)) + 1; // using a list with a virtual bottom row
										// to be connected to the virtual bottom
										// of the list.
		// creates the WeightedQuickUnionUF to be of size n*(n+1) +1 for the
		// virtual bottom row and bottom of the simulation
		uf1 = new WeightedQuickUnionUF(bottom);

		// connects the first row of the list elements to the virtual top
		for (int i = 1; i <= n; i++) {
			uf1.union(top, i);

		}
		// connects the virtual bottom to the virtual bottom row of the matrix
		for (int i = (bottom - 1) - (dim); i <= (bottom - 2); i++) {
			uf1.union(i, bottom - 1);
		}
		}catch(IllegalArgumentException e)
		{
			System.out.println(e.getMessage());

		}

	}

	/**
	 * open the site (row i, col j)
	 *
	 * @param i
	 *            Value of the row
	 * @param j
	 *            Value of the column
	 */
	public void open(int i, int j) {
		try {

			if (i > this.dim - 1 || i < 0) {
				throw new IndexOutOfBoundsException("Int i cannot be less than 0 or greater than " + (dim - 1));
			} else if (j > this.dim - 1 || j < 0) {
				throw new IndexOutOfBoundsException("Int j cannot be less than 0 or greater than " + (dim - 1));
			}
			// The block enclosed below ensures the value of the site
			// matches the value of the element in the QuickUnionUF
			// \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
			if (sites[i][j] == 1)// \\
			{ // \\
				return;
			}

			sites[i][j] = 1;
			counter++;
			int elem = 1;
			if (i > 0 && j > 0) {
				elem = ((dim * i) + 1) + (j);
			} else {
				if (i == 0 || j == 0) {
					if (i == 0 && j == 0) {
						elem = 1 + dim;

					} else if (i == 0 && j != 0) {
						elem = (j + 1) + dim;
					} else if (j == 0 && i != 0) {
						elem = (dim * i) + dim + 1;
					}
				} //
					//
			} //
				/////////////////////////////////////////////////////////////

			// The if statements below ensure no calls cause an exception of
			// the ArrayElementOutOfBounds variety

			if (i != 0 && this.isOpen(i - 1, j)) {
				uf1.union(elem, elem - dim);
				// System.out.println("Connection up"); // needed for
				// troubleshooting
			}

			if (j != 0 && this.isOpen(i, j - 1)) {
				uf1.union(elem, elem - 1);
				// System.out.println("Connection left"); // needed for
				// troubleshooting
			}
			if (j < dim - 1 && this.isOpen(i, j + 1)) {
				uf1.union(elem, elem + 1);
				// System.out.println("Connection right"); // needed for
				// troubleshooting
			}

			if (i < dim - 1 && this.isOpen(i + 1, j)) {
				uf1.union(elem, elem + dim);
				// System.out.println("Connection down"); // needed for
				// troubleshooting
			}
			if (i == dim - 1) {
				uf1.union(elem, elem + dim);
			}
			if (i == 0) {
				uf1.union(elem, elem - dim);
			}
			// Obligatory Exception catch statement for the try-catch
		} catch (ArrayIndexOutOfBoundsException e) {
			errs++;
			System.out.println(errs);
			System.out.println("i = " + i + "j = " + j + "Index must be 0<=index<=dim-1");
			System.out.println("Exception caught");

		}

	}

	/**
	 * checks whether or not the site is open
	 *
	 * @param i
	 *            Value of the row
	 * @param j
	 *            Value of the column
	 * @return
	 */
	public boolean isOpen(int i, int j) {

		try {
			if (i > this.dim - 1 || i < 0) {
				throw new IndexOutOfBoundsException("Int i cannot be less than 0 or greater than " + (dim - 1));
			} else if (j > this.dim - 1 || j < 0) {
				throw new IndexOutOfBoundsException("Int j cannot be less than 0 or greater than " + (dim - 1));
			}
			// if open returns true, else false
			if (this.sites[i][j] == 1) {
				return true;
			} else {
				return false;
			}
		} catch (IndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
		}
		return false;

	}

	// is the site (row i, col j) full?
	/**
	 * checks whether or not the site is closed off
	 *
	 * @param i
	 *            Value of the row
	 * @param j
	 *            Value of the column
	 * @return
	 */
	public boolean isFull(int i, int j) {
		try {
			if (i > this.dim - 1 || i < 0) {
				throw new IndexOutOfBoundsException("Int i cannot be less than 0 or greater than " + (dim - 1));
			} else if (j > this.dim - 1 || j < 0) {
				throw new IndexOutOfBoundsException("Int j cannot be less than 0 or greater than " + (dim - 1));
			}

			// if full returns true, else false
			if (this.sites[i][j] != 1) {
				return true;
			} else {
				return false;
			}
		} catch (IndexOutOfBoundsException e) {
			System.out.println(e.getMessage());
		}
		return false;
	}

	/**
	 * Checks whether or not the top connects to the bottom
	 *
	 * @return
	 */
	public boolean percolates() {

		if (uf1.connected(0, bottom - 1)) {
			/**
			 * System.out.println(uf1.connected(top, bottom-1)); // prints out
			 * true once system percolates no longer needed
			 */
			return true;
		}
		/**
		 * System.out.println(uf1.connected(top, bottom-1)); // prints false as
		 * checked no longer needed
		 */
		return false;

	}

	/**
	 * iterates through the matrix and prints the elements to the console added
	 * for visualizing the process in the console, only used for testing and
	 * in the main method below to show the system when it percolates
	 */
	private void printSim() {
		for (int i = 0; i < this.sites.length; i++) {
			for (int j = 0; j <= this.sites.length - 1; j++) {
				if (j == this.sites.length - 1) {
					System.out.print(" " + this.sites[i][j] + "\n");

				} else {
					System.out.print(" " + this.sites[i][j]);
				}
			}
		}
	}

	/**
	 *
	 * @param perc
	 *            The percolation object sent to be filled until it percolates,
	 *            generates random values to be sent as indices of the matrix
	 */
	public void fillSites(Percolation perc) {

		while (!perc.percolates())

		// fills sites at random
		{
			int a = StdRandom.uniform(0, dim);
			int b = StdRandom.uniform(0, dim);
			//System.out.println("a = " + a + "b = " + b);
			perc.open(a,b);

			// uncomment line below to watch the percolation happen in real-time
			// on the console
			// significantly reduces speed of calculations

//			System.out.println();
//			 printSim();

		}
	}

	/**
	 * Main testing environment for the percolation simulation
	 *
	 * @param args
	 */
	public static void main(String[] args) {

		// creates a new matrix of dimensions passed, add any number to create
		// the array of param^2

		Percolation perc = new Percolation(100);

		// added int total_sites and dim to use instead of the static call to
		// dim
		int dim = perc.dim;
		int TotalSites = dim * dim;

		System.out.println("\n\n");

		System.out.println("virtual top row connected to virtual top");

		// shows the top is connected to the top row
		for (int i = 0; i < dim; i++) {
			System.out.println(perc.uf1.connected(0, i));

		}

		// shows the bottom is connected to the bottom virtual row
		System.out.println("Bottom virtual row connected to virtual bottom");
		for (int i = (perc.bottom - 1) - dim; i <= perc.bottom - 2; i++) {
			System.out.println(perc.uf1.connected(perc.bottom - 1, i));

		}
		// shows the system does not percolate to begin with
		System.out.println("Is connected top to bottom? " + perc.uf1.connected(TotalSites - 1, 0));
		System.out.println("\n\n");


		// fills the sites at random and starts a clock which ends once it is
		// complete
		double starttime = System.nanoTime();
		System.out.println("Starting Simulation\n\n");
		perc.fillSites(perc);
		double endtime = System.nanoTime();
		System.out.println("\n\nSimulation Complete");
		// prints the matrix with randomly opened sites
		System.out.println("\n\n\n\n\n\n\n\n");
		perc.printSim();

		// shows the system percolates once complete and gives a runtime
		System.out.println(perc.percolates());
		System.out.println("\nTotal runtime = " + String.format("%.2f", ((endtime - starttime) / 1000000000)) + " sec");

		// a counter is used to keep track of the opened sites and we can use to
		// compare to the total number of sites
		// to use in the stats for calculating the number of total sites to open
		// sites.
		System.out.println(perc.counter + " Sites total have been opened out of " + TotalSites + " Sites");
		System.out.println(
				"This makes the value of p* (Threshhold) " + " = " + ((double) perc.counter / ((double) TotalSites)));



	}

}
