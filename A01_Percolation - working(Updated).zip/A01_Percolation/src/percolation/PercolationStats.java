package percolation;

public class PercolationStats {

	public static void methodC(int[] a)
	{
	int result = 0;
	int n = a.length;
	for (int i=0; i < n; i++)
	{
	result = result + a[i];
	}
	}

	public static void main(String[] args) {


	}


}
