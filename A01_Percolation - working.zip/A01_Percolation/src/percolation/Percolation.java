/**
 * A01 Percolation assignment
 */
package percolation;

import java.util.Random;


import edu.princeton.cs.algs4.QuickUnionUF;

/**
 *
 * @author Miguel
 *
 */
public class Percolation {

	QuickUnionUF uf1;
	int[][] sites;
	static int dim;
	int top, bottom;
	int counter =0;

	// create N�by�N grid, with all sites blocked
	public Percolation(int n) {
		sites = new int[n][n];
		dim = n;
		top = 0;
		bottom = ((n+1)*(n))+1 ;
		uf1 = new QuickUnionUF(bottom);


		for(int i = 1 ;  i <= n; i++)
		{
			uf1.union(top, i);

		}
		for(int i = n*n-(n)  ; i <=n*n; i++)
		{
			uf1.union( i,bottom-1);
		}

	}

	// open the site (row i, col j)
	public void open(int i, int j) {
		try{

		if(sites[i][j] == 1)
		{
			return;
		}

		sites[i][j] = 1;
		counter++;
		int elem = 1;
		if(i>0 && j>0){
		 elem = ((dim*i)+1)+(j) ;
		}else{
			if(i==0 || j == 0){
				if(i == 0 && j == 0)
				{
					elem = 1;
				}else if (i == 0 && j != 0 )
				{
					elem = j+1;
				}else if(j == 0 && i != 0)
				{
					elem = dim*i+1;
				}
			}

		}

		if(i !=0 && this.isOpen(i-1, j))
		{ uf1.union(elem, elem-dim);
		//System.out.println("Connection up");
		}

		if (j != 0 && this.isOpen(i, j-1))
		{ uf1.union(elem, elem-1);
		//System.out.println("Connection left");
		}
		if(j <dim-1 && this.isOpen(i, j+1))
		{ uf1.union(elem, elem+1) ;
		//System.out.println("Connection right");
		}


		if(i < dim-1 && this.isOpen(i+1, j))
		{ uf1.union(elem, elem+dim);
		//System.out.println("Connection down");
		}
		if (i == dim-1)
		{
			uf1.union(elem, elem+dim);
		}

		}catch(Exception e) {



		System.out.println(counter);
		System.out.println("Exception caught");

		}



	}

	// is the site (row i, col j) open?
	public boolean isOpen(int i, int j) {
		if (this.sites[i][j] == 1) {
			return true;
		} else {
			return false;
		}
	}

	// is the site (row i, col j) full?
	public boolean isFull(int i, int j) {
		if (this.sites[i][j] != 1) {
			return true;
		} else {
			return false;
		}
	}

	// does the system percolate?
	// I have not started on this one yet
	public boolean percolates() {

		if (uf1.connected(0, bottom-1)){
			//System.out.println(uf1.connected(top, bottom-1)); // prints out true once system percolates
			return true;
		}
		//System.out.println(uf1.connected(top, bottom-1));		// prints false as checked
		return false;

	}

	// iterates through the matrix and prints to console
	private static void printSim(Percolation perc) {
		for (int i = 0; i < perc.sites.length; i++) {
			for (int j = 0; j <= perc.sites.length - 1; j++) {
				if (j == perc.sites.length - 1) {
					System.out.print(" " + perc.sites[i][j] + "\n");

				} else {
					System.out.print(" " + perc.sites[i][j]);
				}
			}
		}
	}

	// fills the sites at random in nxn matrix sites
	private static void fillSites(Percolation perc) {

		while (!perc.percolates())

//		This block of code below fills the array sequentially from 0x0 to nxn
//		{
//			for (int i = 0;i<dim ; i++)
//			{
//				for (int j = 0 ; j < dim; j++)
//				{
//					perc.open(i, j);
//					System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n");
//					printSim(perc);
//				}
//			}
//		}



			//   fills at a random rate


		{
			Random a = new Random();
			Random b = new Random();
			perc.open((int)(a.nextDouble()*perc.dim), (int)(b.nextDouble()*perc.dim));

			System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n");
			printSim(perc);

			//System.out.println((int)(a.nextDouble()*perc.dim));
		}
	}

	public static void main(String[] args) {

		// creates a new matrix of size passed
		Percolation perc = new Percolation(50);
System.out.println("\n\n" );

System.out.println("top row connected to virtual top");

		for(int i = 0 ; i < dim; i ++)
		{
			System.out.println(perc.uf1.connected(0, i ));

		}

		System.out.println("Bottom virtual row connected to virtual bottom");
		for(int i = dim*dim-dim ; i <= dim*dim-1; i ++)
		{
			System.out.println(perc.uf1.connected(dim*dim-1, i ));

		}
		System.out.println("Is connected top to bottom? " + perc.uf1.connected(dim*dim-1, 0 ));
		System.out.println("\n\n" );
		// shows the matrix is all zeros to begin with
		//printSim(perc);

		// fills the sites at random
		fillSites(perc);



		// prints the matrix with randomly opened sites
		System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
		printSim(perc);

		System.out.println(perc.percolates());


		// a counter is used to keep track of the opened sites and we can use to compare to the total number of sites
		// to use in the stats for calculating the number of total sites to open sites.
		System.out.println(perc.counter + " Sites total have been opened out of " + dim*dim + " Sites");
		System.out.println("This makes the ");

	}

}
